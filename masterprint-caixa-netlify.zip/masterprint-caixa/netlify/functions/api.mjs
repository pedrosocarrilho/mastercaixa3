// MasterPrint Caixa — API (Netlify Functions + Netlify Blobs)
// Variáveis de ambiente opcionais: CONVITE (exige código para criar conta) e CHAVE_MESTRA (reset de emergência).
import { getStore } from '@netlify/blobs';
import { pbkdf2, randomBytes, timingSafeEqual, createHash } from 'node:crypto';
import { promisify } from 'node:util';

const pb = promisify(pbkdf2);
export const config = { path: '/api/*' };

const out = (s, o) => new Response(JSON.stringify(o), { status: s, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' } });
const bad = (s, m) => out(s, { erro: m });
const sha = s => createHash('sha256').update(s).digest('hex');
const rid = n => randomBytes(n).toString('hex');
const eq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && timingSafeEqual(x, y); };
const hp = async (pw, salt) => (await pb(pw, salt, 120000, 32, 'sha256')).toString('hex');
const J = (db, k) => db.get(k, { type: 'json' });
const pub = u => ({ id: u.id, name: u.nome, user: u.usuario, role: u.role });
const norm = s => String(s || '').trim().toLowerCase();
const okUser = s => /^[a-z0-9._-]{3,30}$/.test(s);
const okPw = s => typeof s === 'string' && s.length >= 6 && s.length <= 200;
const txt = (s, n) => typeof s === 'string' && s.trim().length > 0 && s.trim().length <= n;
const KEYS = { prods: 'put', cx: 'put', closures: 'put', sales: 'merge', orders: 'merge' };
const dk = (loja, k) => `d:${loja}:${k}`;

function genCode() {
  const a = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', r = randomBytes(16);
  return [0, 4, 8, 12].map(i => [...r.subarray(i, i + 4)].map(x => a[x % a.length]).join('')).join('-');
}
const normCode = c => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');

// leitura-modificação-escrita com controle de concorrência (etag)
async function mutate(db, key, fn) {
  for (let i = 0; i < 14; i++) {
    if (i) await new Promise(r => setTimeout(r, Math.random() * 30 * (i + 1)));
    const cur = await db.getWithMetadata(key, { type: 'json' });
    const rev = cur ? +(cur.metadata && cur.metadata.rev) || 0 : 0;
    const v = fn(cur ? cur.data.v : null);
    const r = await db.setJSON(key, { v }, { metadata: { rev: rev + 1 }, ...(cur ? { onlyIfMatch: cur.etag } : { onlyIfNew: true }) });
    if (!r || r.modified !== false) return { rev: rev + 1, prev: rev, v };
  }
  throw new Error('conflito de escrita');
}

async function lockLeft(db, k) { const f = await J(db, 'f:' + k); return f && f.until > Date.now() ? Math.ceil((f.until - Date.now()) / 1000) : 0; }
async function fail(db, k, max, secs) { const f = (await J(db, 'f:' + k)) || { n: 0 }; let n = (f.n || 0) + 1, until = 0; if (n >= max) { until = Date.now() + secs * 1000; n = 0; } await db.setJSON('f:' + k, { n, until }); }

async function session(db, u) {
  const tok = rid(32);
  await db.setJSON('s:' + sha(tok), { usuario: u.usuario, loja: u.loja, pv: u.pv, exp: Date.now() + 30 * 864e5 });
  return tok;
}
async function auth(db, req) {
  const m = /^Bearer ([a-f0-9]{64})$/.exec(req.headers.get('authorization') || '');
  if (!m) return null;
  const th = sha(m[1]), s = await J(db, 's:' + th);
  if (!s || s.exp < Date.now()) return null;
  const u = await J(db, 'u:' + s.usuario);
  if (!u || u.pv !== s.pv || u.loja !== s.loja) return null;
  return { u, th };
}
const usersOf = async (db, loja) => ((await J(db, `l:${loja}:users`)) || {}).v || [];

async function newUser(db, loja, { nome, usuario, senha, role }) {
  const salt = rid(16), u = { id: rid(6), nome: nome.trim(), usuario, role, loja, salt, hash: await hp(senha, salt), pv: 1 };
  const r = await db.setJSON('u:' + usuario, u, { onlyIfNew: true });
  if (r && r.modified === false) return null;
  await mutate(db, `l:${loja}:users`, a => [...(a || []), usuario]);
  return u;
}
async function setPassword(db, u, senha) {
  u.salt = rid(16); u.hash = await hp(senha, u.salt); u.pv = (u.pv || 1) + 1;
  await db.setJSON('u:' + u.usuario, u);
}

async function signup(db, b) {
  if (process.env.CONVITE && !eq(b.convite || '', process.env.CONVITE)) return bad(403, 'Código de convite inválido.');
  const usuario = norm(b.usuario);
  if (!txt(b.loja, 80) || !txt(b.nome, 80)) return bad(400, 'Informe o nome da loja e o seu nome.');
  if (!okUser(usuario)) return bad(400, 'Usuário: 3 a 30 caracteres (letras minúsculas, números, ponto, hífen ou sublinhado).');
  if (!okPw(b.senha)) return bad(400, 'A senha precisa ter ao menos 6 caracteres.');
  const loja = rid(8), u = await newUser(db, loja, { nome: b.nome, usuario, senha: b.senha, role: 'admin' });
  if (!u) return bad(409, 'Este usuário já existe. Escolha outro.');
  const codigo = genCode(), salt = rid(16);
  await db.setJSON(`l:${loja}:meta`, { nome: b.loja.trim(), rec: { salt, hash: await hp(normCode(codigo), salt) } });
  return out(200, { token: await session(db, u), user: pub(u), loja: { nome: b.loja.trim() }, codigo });
}

async function login(db, b) {
  const usuario = norm(b.usuario);
  const left = await lockLeft(db, usuario);
  if (left) return bad(429, `Muitas tentativas. Aguarde ${left}s e tente de novo.`);
  const u = okUser(usuario) ? await J(db, 'u:' + usuario) : null;
  const h = await hp(String(b.senha || ''), u ? u.salt : '0'.repeat(32));
  if (!u || !eq(h, u.hash)) { await fail(db, usuario, 5, 60); return bad(401, 'Usuário ou senha incorretos.'); }
  await db.delete('f:' + usuario);
  const meta = await J(db, `l:${u.loja}:meta`);
  return out(200, { token: await session(db, u), user: pub(u), loja: { nome: meta ? meta.nome : '' } });
}

async function recover(db, b) {
  const usuario = norm(b.usuario), k = 'rec:' + usuario;
  const left = await lockLeft(db, k);
  if (left) return bad(429, `Muitas tentativas. Aguarde ${Math.ceil(left / 60)} min.`);
  if (!okPw(b.nova)) return bad(400, 'A nova senha precisa ter ao menos 6 caracteres.');
  const u = okUser(usuario) ? await J(db, 'u:' + usuario) : null;
  let ok = false;
  if (u && u.role === 'admin') {
    const meta = await J(db, `l:${u.loja}:meta`), c = String(b.codigo || '');
    if (meta && meta.rec && eq(await hp(normCode(c), meta.rec.salt), meta.rec.hash)) ok = true;
    else if (process.env.CHAVE_MESTRA && eq(c, process.env.CHAVE_MESTRA)) ok = true;
  }
  if (!ok) { await fail(db, k, 5, 300); return bad(401, 'Código ou usuário incorreto.'); }
  await setPassword(db, u, b.nova); await db.delete('f:' + k);
  return out(200, { ok: 1 });
}

async function route(req, db) {
  const url = new URL(req.url), p = url.pathname.replace(/^\/api\/?/, '').split('/').filter(Boolean), m = req.method, r0 = p[0];
  let b = {};
  if (m === 'POST' || m === 'PUT' || m === 'PATCH') {
    if (+req.headers.get('content-length') > 4.5e6) return bad(413, 'Dados muito grandes.');
    try { b = await req.json(); } catch { return bad(400, 'Requisição inválida.'); }
    if (!b || typeof b !== 'object' || Array.isArray(b)) return bad(400, 'Requisição inválida.');
  }
  if (r0 === 'config' && m === 'GET') return out(200, { convite: !!process.env.CONVITE });
  if (r0 === 'signup' && m === 'POST') return signup(db, b);
  if (r0 === 'login' && m === 'POST') return login(db, b);
  if (r0 === 'recover' && m === 'POST') return recover(db, b);

  const a = await auth(db, req);
  if (!a) return bad(401, 'Sessão expirada. Entre novamente.');
  const { u } = a, admin = u.role === 'admin', loja = u.loja;

  if (r0 === 'me' && m === 'GET') { const meta = await J(db, `l:${loja}:meta`); return out(200, { user: pub(u), loja: { nome: meta ? meta.nome : '' } }); }
  if (r0 === 'logout' && m === 'POST') { await db.delete('s:' + a.th); return out(200, { ok: 1 }); }

  if (r0 === 'password' && m === 'POST') {
    if (!okPw(b.nova)) return bad(400, 'A nova senha precisa ter ao menos 6 caracteres.');
    if (!eq(await hp(String(b.atual || ''), u.salt), u.hash)) return bad(403, 'Senha atual incorreta.');
    await setPassword(db, u, b.nova);
    return out(200, { token: await session(db, u) });
  }

  if (r0 === 'rev' && m === 'GET') {
    const rev = {};
    await Promise.all(Object.keys(KEYS).map(async k => { const g = await db.getMetadata(dk(loja, k)); rev[k] = g && g.metadata ? +g.metadata.rev || 0 : 0; }));
    return out(200, { rev });
  }
  if (r0 === 'data' && m === 'GET') {
    const get = async k => { const g = await db.getWithMetadata(dk(loja, k), { type: 'json' }); return { v: g ? g.data.v : null, rev: g ? +g.metadata.rev || 0 : 0 }; };
    if (!p[1]) { const data = {}; await Promise.all(Object.keys(KEYS).map(async k => { data[k] = await get(k); })); return out(200, { data }); }
    if (!KEYS[p[1]]) return bad(404, 'Não encontrado.');
    return out(200, await get(p[1]));
  }
  if (r0 === 'data' && (m === 'PUT' || m === 'PATCH') && KEYS[p[1]]) {
    const k = p[1], type = KEYS[k];
    if (k === 'prods' && !admin) return bad(403, 'Apenas a administradora altera preços e produtos.');
    if (type === 'put' && m === 'PUT') {
      const v = b.value;
      if (k === 'cx' ? !(v && typeof v === 'object' && !Array.isArray(v)) : !Array.isArray(v)) return bad(400, 'Dados inválidos.');
      const r = await mutate(db, dk(loja, k), () => v);
      return out(200, { rev: r.rev, prev: r.prev });
    }
    if (type === 'merge' && m === 'PATCH') {
      const up = b.upsert;
      if (!Array.isArray(up) || up.length > 500 || up.some(x => !x || typeof x !== 'object' || typeof x.id !== 'string' || x.id.length > 64)) return bad(400, 'Dados inválidos.');
      const r = await mutate(db, dk(loja, k), cur => {
        const map = new Map((cur || []).map(x => [x.id, x]));
        for (const x of up) { const e = map.get(x.id); if (!e || (+x.u || 0) >= (+e.u || 0)) map.set(x.id, x); }
        return [...map.values()];
      });
      return out(200, { rev: r.rev, prev: r.prev });
    }
    return bad(405, 'Método não permitido.');
  }

  // ---- administração (somente administradora)
  if (['users', 'recovery'].includes(r0)) {
    if (!admin) return bad(403, 'Apenas a administradora pode fazer isso.');
    if (r0 === 'recovery' && p[1] === 'new' && m === 'POST') {
      const codigo = genCode(), salt = rid(16), meta = (await J(db, `l:${loja}:meta`)) || {};
      await db.setJSON(`l:${loja}:meta`, { ...meta, rec: { salt, hash: await hp(normCode(codigo), salt) } });
      return out(200, { codigo });
    }
    if (r0 === 'users') {
      const names = await usersOf(db, loja), all = (await Promise.all(names.map(n => J(db, 'u:' + n)))).filter(Boolean);
      if (!p[1] && m === 'GET') return out(200, { users: all.map(pub) });
      if (!p[1] && m === 'POST') {
        const usuario = norm(b.usuario);
        if (!txt(b.nome, 80)) return bad(400, 'Informe o nome.');
        if (!okUser(usuario)) return bad(400, 'Usuário: 3 a 30 caracteres (letras minúsculas, números, ponto, hífen ou sublinhado).');
        if (!okPw(b.senha)) return bad(400, 'A senha precisa ter ao menos 6 caracteres.');
        if (all.length >= 30) return bad(400, 'Limite de 30 usuários atingido.');
        const nu = await newUser(db, loja, { nome: b.nome, usuario, senha: b.senha, role: b.role === 'admin' ? 'admin' : 'op' });
        return nu ? out(200, { user: pub(nu) }) : bad(409, 'Este usuário já existe. Escolha outro.');
      }
      const t = all.find(x => x.id === p[1]);
      if (p[1] && !t) return bad(404, 'Usuário não encontrado.');
      if (p[1] && m === 'PATCH') {
        if (!okPw(b.senha)) return bad(400, 'A senha precisa ter ao menos 6 caracteres.');
        await setPassword(db, t, b.senha); return out(200, { ok: 1 });
      }
      if (p[1] && m === 'DELETE') {
        if (t.id === u.id) return bad(400, 'Você não pode remover o próprio usuário.');
        if (t.role === 'admin' && all.filter(x => x.role === 'admin').length < 2) return bad(400, 'É preciso manter ao menos uma administradora.');
        await db.delete('u:' + t.usuario);
        await mutate(db, `l:${loja}:users`, a => (a || []).filter(n => n !== t.usuario));
        return out(200, { ok: 1 });
      }
    }
  }
  return bad(404, 'Não encontrado.');
}

export default async (req) => {
  try { return await route(req, getStore({ name: 'caixa', consistency: 'strong' })); }
  catch (e) { console.error(e); return bad(500, 'Erro interno. Tente novamente.'); }
};
