# MasterPrint Caixa — colocar no ar no Netlify

Sistema de caixa, pedidos e orçamentos com **criação de conta, login e dados salvos na nuvem**
(Netlify Functions + Netlify Blobs). Cada loja cria a própria conta; os dados ficam separados por loja.

> O arraste-e-solte do Netlify Drop **não** serve para este projeto, porque o servidor precisa
> instalar uma dependência. Use um dos dois caminhos abaixo (ambos gratuitos para começar).

## Caminho A — pelo GitHub (recomendado)
1. Crie uma conta em github.com e um repositório novo (privado).
2. Envie **o conteúdo desta pasta** para o repositório (botão "Add file > Upload files").
3. Em app.netlify.com: **Add new project > Import an existing project > GitHub** e escolha o repositório.
4. Deixe as configurações como estão (o arquivo `netlify.toml` já define tudo) e clique em **Deploy**.
5. Em poucos minutos você recebe um endereço `https://...netlify.app`.

## Caminho B — pelo computador (Netlify CLI)
Precisa do Node.js instalado (nodejs.org). Dentro desta pasta:
```
npm install
npm install -g netlify-cli
netlify login
netlify deploy --prod
```
Na primeira vez, responda às perguntas: criar um novo projeto e escolher o nome.
Para testar antes, sem publicar: `netlify dev`.

## Depois de publicar (faça nesta ordem)
1. Abra o endereço, clique em **Criar conta** e cadastre a administradora da loja.
2. **Anote em papel o código de recuperação** que aparece (ele só é mostrado uma vez).
3. Proteja o seu site: no Netlify, **Project configuration > Environment variables**, crie:
   - `CONVITE` = uma palavra-passe sua. Depois disso, só quem souber o código consegue criar contas novas
     (sem isso, qualquer pessoa que descobrir o endereço poderia criar contas e gastar o seu limite).
   - `CHAVE_MESTRA` (opcional) = uma senha longa só sua. Serve para redefinir a senha de uma administradora
     que perdeu o código de recuperação (use o campo "código" da tela "Esqueci minha senha").
   Depois de criar as variáveis, faça um novo deploy (Deploys > Trigger deploy).
4. Cadastre os operadores em **Usuários**.
5. Para trazer os dados da versão antiga (de teste): lá, **Vendas e caixa > Backup > Gerar backup**;
   aqui, cole o texto e toque em **Importar** (só funciona em conta sem vendas e pedidos).

## Instalar como aplicativo
Abra o endereço no Chrome/Edge (computador ou Android) e use "Instalar", ou no iPhone
Safari > Compartilhar > Adicionar à Tela de Início.

## Bom saber
- Agora o sistema **precisa de internet** para entrar e salvar. Se a conexão cair, o caixa mostra o aviso
  "Sem conexão" e tenta enviar de novo sozinho; não feche a página enquanto houver aviso.
- Vários caixas podem usar ao mesmo tempo; as telas se atualizam sozinhas a cada ~15 segundos.
  Se dois caixas fecharem uma venda no mesmo segundo, os números de venda podem repetir (os valores não se perdem).
- Senhas são guardadas com criptografia (PBKDF2); 5 tentativas erradas bloqueiam o usuário por 1 minuto.
- Confira os limites do seu plano no Netlify (funções e armazenamento) conforme o volume de vendas.

## Estrutura
- `public/` — o aplicativo (index.html, ícones, manifesto, service worker)
- `netlify/functions/api.mjs` — o servidor (contas, login, dados)
- `netlify.toml`, `package.json` — configuração
